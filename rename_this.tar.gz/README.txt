OPERATING SYSTEMS - HOMEWORK 2
PROCESS MANAGEMENT SIMULATION SYSTEM

Zachary Vanderzee
Rocco Del Priore
Caitlin Connerney

Python Version 2.7.6

m is number of cores
n is number of processes
timeLimit is Burst Time in Round Robin

All processes are randomly generated and assigned a random priority. All algorithms are passed the same
randomly generated processes but are randomly assigned new times after their first completion